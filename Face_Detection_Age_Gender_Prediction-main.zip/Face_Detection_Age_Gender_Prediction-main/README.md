# Face Detection with Age and gender prediction
# Description
It is a web application which detects the face of the person and then estimate the age and gender of that person. This projects works for given image as wll as live images through the web cam.

# Dataset
We have used Adience dataset in this project. This dataset contains 26,580 photos across 2284 subjects with a binary gender label and one label from eight different age groups, partitioned into five split.

# Tech Stack
- Language : Python
- Algorithm : CNN
- Web Framwork : Flask

# Output
As a output, this model build a square line around the faces in the image and shows the predicted age group label and gender of the person in the image.

# Future Work
- This works on a local system, we can deploy it on a cloud.
- We can improve the accuracy by using more data, data augmentation and better network architectures.
